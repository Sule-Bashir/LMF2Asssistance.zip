package com.lfm2assistant.leap

import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.nanohttpd.protocols.http.IHTTPSession
import org.nanohttpd.protocols.http.NanoHTTPD
import org.nanohttpd.protocols.http.response.Response
import org.nanohttpd.protocols.http.response.ResponseException

class LeapService : Service() {

    private val leapModel = object {
        fun run(uri: Uri, prompt: String): String {
            return "Processed image: ${uri.lastPathSegment} with mode: $prompt"
        }
    }

    private lateinit var server: LocalApiServer

    override fun onCreate() {
        super.onCreate()
        server = LocalApiServer(8080, leapModel)
        server.start()
        Log.d("LeapService", "LEAP service started on port 8080")
    }

    override fun onDestroy() {
        super.onDestroy()
        server.stop()
        Log.d("LeapService", "LEAP service stopped")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class LocalApiServer(port: Int, private val leapModel: Any) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        return try {
            if (session.uri == "/analyze" && session.method.name == "POST") {
                val params = session.parms
                val imageUri = params["imageUri"] ?: return newFixedLengthResponse("Missing imageUri")
                val mode = params["mode"] ?: "General"

                var resultText = leapModel.javaClass.methods
                    .firstOrNull { it.name == "run" }
                    ?.invoke(leapModel, Uri.parse(imageUri), mode)
                    ?.toString() ?: "No result"

                newFixedLengthResponse("{"result": "$resultText"}")
            } else {
                newFixedLengthResponse("LEAP service running")
            }
        } catch (e: ResponseException) {
            newFixedLengthResponse("Error: ${e.message}")
        }
    }
}
